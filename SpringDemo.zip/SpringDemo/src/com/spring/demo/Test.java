package com.spring.demo;
public class Test {

	public Test()
	{
		System.out.println("From Default constructor");
	}
	
	public void m1()
	{
		System.out.println("am from m1 method");
	}
}
