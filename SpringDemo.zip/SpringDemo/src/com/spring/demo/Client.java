package com.spring.demo;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	public static void main(String[] args) {
		Resource resource = new ClassPathResource("springconfig.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
//		ApplicationContext context=new ClassPathXmlApplicationContext("springconfig.xml");
		Test test = (Test) factory.getBean("test");
		System.out.println(test);
		test.m1();
		//Test test=new Test();
	}
}
