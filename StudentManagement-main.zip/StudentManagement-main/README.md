# StudentManagement
Student Management System is a basic CRUD Restful API created using Java, Spring Boot, JDBC Template, and MySQL.

A detailed explanation of the implementation of this project is present here- https://medium.com/p/aa9cc7855025

Reach me out at- https://www.linkedin.com/in/gauravshah97/
