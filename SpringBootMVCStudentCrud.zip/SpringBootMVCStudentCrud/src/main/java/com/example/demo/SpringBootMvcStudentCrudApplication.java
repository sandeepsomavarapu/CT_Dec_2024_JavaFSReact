package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcStudentCrudApplication {

	public static void main(String[] args) {

		SpringApplication.run(SpringBootMvcStudentCrudApplication.class, args);
	}

}
