package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Employee1ToMBi {
	@Id
	private int empId;
	
    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department1ToMBi department;
 
}