package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Department1ToM {
	@Id
	private Long id;
	@OneToMany
	@JoinColumn(name = "department_id")
	private List<Employee1ToM> employees;
}
