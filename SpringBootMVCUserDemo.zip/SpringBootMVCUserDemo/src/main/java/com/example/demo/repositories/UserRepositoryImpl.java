package com.example.demo.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.model.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class UserRepositoryImpl implements UserRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<User> getAllUsers() {

		return entityManager.createQuery("select u from User u", User.class).getResultList();
	}

}
