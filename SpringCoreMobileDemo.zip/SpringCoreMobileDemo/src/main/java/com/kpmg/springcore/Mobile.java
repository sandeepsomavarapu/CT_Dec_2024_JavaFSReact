package com.kpmg.springcore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("mobile")
public class Mobile {
	@Autowired
	@Qualifier("jio")
	Sim sim;//has-a/composition
	
	public void call() {
		sim.call();
	}
	public void browse() {
		sim.browse();
	}
	public void sendSms() {
		sim.sendSms();
	}
	public void sendMms() {
		sim.sendMms();
	}
	
	

}
