package com.cts;

import org.springframework.beans.factory.annotation.Value;

public interface Address {
	
}
