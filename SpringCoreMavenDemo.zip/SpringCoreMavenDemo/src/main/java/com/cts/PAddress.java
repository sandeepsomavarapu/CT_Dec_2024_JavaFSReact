package com.cts;

import org.springframework.stereotype.Component;

@Component("padd")
public class PAddress implements Address {

}
