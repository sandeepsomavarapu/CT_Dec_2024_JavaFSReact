package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cts")
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
		Employee emp = (Employee) context.getBean("employee");
		System.out.println(emp);
		TAddress tadd=(TAddress) emp.getAddress();
		System.out.println(tadd.getHno());
	
	}
}
